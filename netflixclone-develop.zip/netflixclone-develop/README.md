# NETFLIX CLONE

This project is a simply front end clone of Netflix. It was created with React. It uses The MovieDB Api to search for movies and display details.

## PACKAGES I USE

* React-youtube
* TMDB Api
* Axios
* Movie Trailer



## Demo Link :https://lucid-benz-6af4ca.netlify.app/

![screenshot-1](https://user-images.githubusercontent.com/22106880/147141573-1865cb4e-5adc-46c5-9256-6c3e8d509a23.png)
![screenshot-1](https://user-images.githubusercontent.com/22106880/147141729-fbf38f29-6468-45bb-9068-c6b4183eac79.png)
